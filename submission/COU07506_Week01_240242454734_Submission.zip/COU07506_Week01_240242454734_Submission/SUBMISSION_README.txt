COU07506 - Week 01 / Lab 0: Setting Up the DSP Laboratory
SHEMSA NASSOR AMIN | 240242454734 | BEng24COE | Group 16

Main submission: COU07506_Week01_240242454734.ipynb
Open in Jupyter, VS Code, or Google Colab. All Python cells have been run;
plots and an audio player are saved in the notebook.

outputs/ contains four figures and lab0_processed.wav: the manual's
fallback 440 Hz tone (16,000 Hz, 2 seconds, mono, 16-bit PCM).
No personal voice recording is included.

For a phone recording, add a 3-5 second my_voice.wav beside the notebook,
update the audio description and analysis answer, then restart and run all
cells. Include that recording and the updated outputs when repackaging.

week01_lab0.py contains the notebook computations as a standalone program.
Install numpy, scipy, and matplotlib, then run:
  python week01_lab0.py
Use --show to display plot windows. Figures and the WAV are saved to outputs/.

week01_lab0.m is the optional Octave/MATLAB script; it has not been run
in Octave/MATLAB. requirements.txt lists the Python packages for local use.

Review the pre-lab device examples and complete the understanding declaration
before uploading. Instructor sign-off and eLMS upload remain personal steps.
The manual specifically requests the .ipynb file on eLMS; use the ZIP for
supporting files if the submission form accepts archives.
